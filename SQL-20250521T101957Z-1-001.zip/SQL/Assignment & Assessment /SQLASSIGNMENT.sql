CREATE DATABASE techademy;
USE techademy;
create table employees(emp_id INT PRIMARY KEY NOT NULL,emp_name VARCHAR(250),
dept_id INT ,salary DECIMAL,hire_date DATE,FOREIGN KEY(dept_id) REFERENCES departments(dept_id));
create table departments(dept_id INT primary key not null,dept_name VARCHAR(250));
INSERT INTO employees (emp_id, emp_name, dept_id, salary, hire_date)
VALUES
    (101, 'Johnson Dover', 2, 55000.00, '2020-01-15'),
    (102, 'Janet Jackson', 1, 45000.00, '2018-06-30'),
    (103, 'Arya Stark', 3, 20000.00, '2019-11-01'),
    (104, 'Mikey Brew', 4, 60000.00, '2021-02-20'),
    (105, 'Amal Davis', 5, 47000.00, '2020-05-11'),
    (106, 'Christhu Wils', 6, 80000.00, '2022-07-09'),
    (107, 'Alicia Taylor', 1, 75000.00, '2018-09-22'),
    (108, 'Davood L', 2, 59000.00, '2020-11-30'),
    (109, 'Mohan Hari', 1, 42000.00, '2021-05-15'),
    (110, 'Kent Clark', 3, 65000.00, '2019-03-13');
    
   
 INSERT INTO departments (dept_id, dept_name)
VALUES
    (1, 'HR'),
    (2, 'Marketing'),
    (3, 'Finance'),
    (4, 'Sales'),
    (5, 'IT'),
    (6, 'R&D');
    
SELECT *FROM employees;  
  
 select emp_name from employees where salary>50000;
 
 select distinct dept_id from employees;
 
 select emp_name as EMPLOYEE_NAME,salary as SALARY from employees order by salary desc;

select emp_name AS EMPLOYEE_NAME,hire_date from employees where hire_date > '2020-01-01';

select emp_name AS EMPLOYEE_NAME from employees where emp_name LIKE "J%";

select emp_name AS EMPLOYEE_NAME,salary from employees where salary between 40000 and 60000;

select* from employees where dept_id != 2;

select count(emp_name) from employees;

select d.dept_name, avg(e.salary) from employees as e join departments as d on e.dept_id=d.dept_id
group by d.dept_name;

SELECT MAX(salary) AS highest_salary
FROM employees;

SELECT YEAR(hire_date) AS hire_year, COUNT(*) AS employee_count FROM employees GROUP BY YEAR(hire_date)
ORDER BY hire_year;

SELECT e.emp_name, d.dept_name FROM employees as e JOIN departments as d ON e.dept_id = d.dept_id;

select e.emp_name,d.dept_name from employees as e 
join departments as d on e.dept_id=d.dept_id where dept_name='Sales';

select d.dept_name,count(e.emp_name) from employees e join departments d on e.dept_id=d.dept_id
 group by d.dept_name;

select emp_name,salary from employees where salary=(select max(salary) from employees);

select * from employees where salary > (select avg(salary) from employees);

update employees set salary=salary+(salary*0.1)
where dept_id in (select dept_id from departments where dept_name="HR");
select * from employees;
select * from employees  where dept_id in (select dept_id from departments where dept_name ="HR");

select emp_name,dept_id from employees where salary >(select max(salary) from employees where dept_id=1);
select*from employees where salary < 30000;
delete from employees where salary < 30000;
select * from employees;




